/*global define*/
define( [], function () {
    'use strict';
    return {       
    	showTitles:false,
		showDetails:false,
    	props: { 
    		showLabels: false,
    		floatMode: 'LEFT',
    		initSelectionMode: 'ONCE',
    	}
			
    };
    	
} );
